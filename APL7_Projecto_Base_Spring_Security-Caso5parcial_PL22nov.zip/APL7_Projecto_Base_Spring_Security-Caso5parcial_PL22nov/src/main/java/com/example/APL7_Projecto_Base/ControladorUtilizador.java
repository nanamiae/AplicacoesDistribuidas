package com.example.APL7_Projecto_Base;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import java.security.Principal;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

@Controller

public class ControladorUtilizador {
    @Autowired
    @Qualifier("bdutilizadores")
    private List<Utilizador> bdutilizadores;

    //http://localhost:8080/
    @GetMapping(value = {"/formregistar"})
    public String getIndex() {
        return "registar.html";
    }

    @PostMapping(value={"/registar","/registareditar"})
    public ModelAndView registaUtilizador(@ModelAttribute Utilizador utilizador){
        if (utilizador.getId()==null)//por causa do método editar.
        utilizador.setId(new Random().nextInt(100000));
        else {
            Iterator<Utilizador> iterator = this.bdutilizadores.iterator();
            while (iterator.hasNext()){
                if (iterator.next().getId().equals(utilizador.getId())){
                    iterator.remove();
                }
            }
        }
        this.bdutilizadores.add(utilizador);
        //System.out.println(utilizador.toString());
        ModelAndView modeloEVista = new ModelAndView();
        modeloEVista.addObject(utilizador);
        modeloEVista.setViewName("dados-utilizador.html");
        return modeloEVista;

    }

    //http://localhost:8080/
    @GetMapping("/listar")
    public String getTodosUtilizadores(Model model, Principal principal) {
        System.out.println("A listar todos os utilizadores...");
        model.addAttribute("utilizadores",this.bdutilizadores);
        model.addAttribute("principal",principal);
        return "lista-utilizadores.html";
    }

    //URI: /remover/{id}
    @GetMapping("remover/{id}")
    public String removerUtilizador(@PathVariable("id") Integer id, Model model) {
        System.out.println("ID a remover: "+id);
        Iterator<Utilizador> iterator = this.bdutilizadores.iterator();
        while (iterator.hasNext()){
            if (iterator.next().getId().equals(id)){
                iterator.remove();
            }
        }
        model.addAttribute("utilizadores",this.bdutilizadores);
        return "lista-utilizadores.html";
    }
    //URI: /editar/{id}
    @GetMapping("editar/{id}")
    public String editarUtilizador(@PathVariable("id") Integer id, Model modelo) {
        for (Utilizador utilizador:this.bdutilizadores) {
            System.out.println("ID Utilizador a percorrer " + utilizador.getId());
            if (utilizador.getId().equals(id)) {
                System.out.println("A editar utilizador: "+utilizador.toString());
                modelo.addAttribute("utilizador", utilizador);
                break;
            }
        }
        return "update-utilizador.html";
    }


}
