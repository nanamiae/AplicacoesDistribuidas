package com.example.APL7_Projecto_Base.seguranca;

import com.example.APL7_Projecto_Base.Utilizador;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface RepositorioUtilizador extends JpaRepository<Utilizador,Integer> {
    public Optional<Utilizador> findByNome(String nome);
}
