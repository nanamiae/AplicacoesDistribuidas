package com.example.APL7_Projecto_Base;

import com.example.APL7_Projecto_Base.seguranca.RepositorioUtilizador;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import java.util.ArrayList;
import java.util.List;

@SpringBootApplication
public class SpringBootMainClasse implements ApplicationRunner {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootMainClasse.class, args);
	}

	@Bean(name="bdutilizadores")
	public List<Utilizador> getBdUtilizadores() {
		return new ArrayList<>();
	}

	@Autowired
	RepositorioUtilizador repositorioUtilizador;

	@Qualifier("codificador.bcrypt")
	@Autowired
	BCryptPasswordEncoder passwordEncoder;

	@Override
	public void run(ApplicationArguments args) throws Exception {
		repositorioUtilizador.save(new Utilizador("admin","adf@ipcb.pt",
				passwordEncoder.encode("admin")));

		repositorioUtilizador.save(new Utilizador("utilizador","adf@ipcb.pt",
				passwordEncoder.encode("123456")));

	}
}
