package com.example.APL7_Projecto_Base.seguranca;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
public class ServicoUserDetails implements UserDetailsService {
    @Autowired
    RepositorioUtilizador repositorioUtilizador;
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
   /*     if(repositorioUtilizador.findByNome(username).isPresent())
        {
            return repositorioUtilizador.findByNome(username).get();
        }
        else throw new UsernameNotFoundException("O uitilizador nao existe");
    }*/
        //v2
        return repositorioUtilizador.findByNome(username)
                .orElseThrow(()-> new UsernameNotFoundException("O utilizador nao existe"));
    }
}
