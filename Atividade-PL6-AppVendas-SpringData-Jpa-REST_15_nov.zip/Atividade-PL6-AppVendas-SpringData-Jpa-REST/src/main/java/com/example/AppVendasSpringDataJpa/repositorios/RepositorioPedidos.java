package com.example.AppVendasSpringDataJpa.repositorios;

import com.example.AppVendasSpringDataJpa.modelos.Pedido;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface RepositorioPedidos extends JpaRepository<Pedido,Integer> {
    //(5)
    public Pedido save(Pedido pedido);

    //(6)
    //@Query(select * from PEDIDO p where p.cliente_id=?1, nativeQuery=true)
    public List<Pedido> getPedidoByClienteId(Integer id);
}
