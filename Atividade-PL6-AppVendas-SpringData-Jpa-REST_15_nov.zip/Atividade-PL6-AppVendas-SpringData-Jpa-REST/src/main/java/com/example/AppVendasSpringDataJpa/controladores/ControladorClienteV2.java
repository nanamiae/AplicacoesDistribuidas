package com.example.AppVendasSpringDataJpa.controladores;

import com.example.AppVendasSpringDataJpa.modelos.Pedido;
import com.example.AppVendasSpringDataJpa.repositorios.RepositorioClientes;
import com.example.AppVendasSpringDataJpa.repositorios.RepositorioPedidos;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

@RestController
@RequestMapping("/v2")
public class ControladorClienteV2 {

    @Autowired
    RepositorioClientes repositorioClientes;

    @Autowired
    RepositorioPedidos repositorioPedidos;

    @PostMapping("/clientes/{idcliente}/pedidos")
    @ResponseStatus(HttpStatus.CREATED)
    public Pedido criaPedidoParaClientePeloID (
            @RequestBody Pedido pedido, @PathVariable("idcliente") Integer id){

       try {
           if (repositorioClientes.existsById(id)) {
               return repositorioPedidos.save(pedido);
           }
           else {
               throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Cliente Inexistente");
           }
       } catch (Exception e) {
           throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Erro no pedido: "
                   +e.getLocalizedMessage());
       }



    }
    // DELETE /clientes/1
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @DeleteMapping("/clientes/{id}")
   public void apagarCliente(@PathVariable("id") Integer id){
        try {
            if (repositorioClientes.existsById(id))
                repositorioClientes.deleteById(id);
            else throw new ResponseStatusException(HttpStatus.NOT_FOUND,
                    "Cliente inexistente");
        }
        catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.NOT_ACCEPTABLE,
                    "Pedido Não Aceite");
        }

    }
}
