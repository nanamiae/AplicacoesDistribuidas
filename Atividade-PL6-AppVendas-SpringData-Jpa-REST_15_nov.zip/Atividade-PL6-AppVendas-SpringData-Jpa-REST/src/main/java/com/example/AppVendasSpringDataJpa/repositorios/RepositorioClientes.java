package com.example.AppVendasSpringDataJpa.repositorios;

import com.example.AppVendasSpringDataJpa.modelos.Cliente;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

public interface RepositorioClientes extends JpaRepository<Cliente,Integer> {
    /* Crie um método que cria um Cliente. AJPQL não suporta inserts.
     */
    //(1) ou (4)
    public Cliente save(Cliente cliente);

    //(2)
    public Optional<Cliente> getClienteById(Integer id);

    //(3)
    public List<Cliente> findAll();

    //(10)
    @Modifying
    @Transactional
    void deleteById(Integer id);

}
