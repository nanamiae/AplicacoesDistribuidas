package com.example.AppVendasSpringDataJpa.controladores;

import com.example.AppVendasSpringDataJpa.modelos.Cliente;
import com.example.AppVendasSpringDataJpa.repositorios.RepositorioClientes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

//PASSO 6 da ficha
@Controller
@ResponseBody
@RequestMapping("/v1")
public class ControladorClienteV1 {

    @Autowired
    RepositorioClientes repositorioClientes;

    //(1)
    @RequestMapping(value = "/clientes",method = RequestMethod.POST)
    public ResponseEntity<Cliente> criarCliente(@RequestBody Cliente cliente) {
        try {
            return ResponseEntity.status(HttpStatus.CREATED)
                    .body(repositorioClientes.save(cliente));
        }
        catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }

    //(2)
    @RequestMapping(value = "/clientes/{id}",method = RequestMethod.GET)
    public ResponseEntity<Cliente> getClientePeloID(@PathVariable("id") Integer id) {
        if (repositorioClientes.getClienteById(id).isPresent()) {
            return ResponseEntity.ok()
                    .body(repositorioClientes
                            .getClienteById(id).get());
        }
        else {
            return ResponseEntity.notFound().build();
        }
    }

    //(3)
    @RequestMapping(value = "/clientes",method = RequestMethod.GET)
    public ResponseEntity<List<Cliente>>getTodosClientes(){
        if (repositorioClientes.findAll().isEmpty())
        {
            return ResponseEntity.status(HttpStatus.NO_CONTENT)
                    .body(repositorioClientes.findAll());
        }
        else {
            return ResponseEntity.ok().body(repositorioClientes.findAll());
        }

    }

}
