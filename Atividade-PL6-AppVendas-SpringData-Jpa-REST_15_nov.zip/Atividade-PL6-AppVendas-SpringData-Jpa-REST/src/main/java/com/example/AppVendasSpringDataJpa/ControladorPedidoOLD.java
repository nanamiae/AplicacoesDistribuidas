package com.example.AppVendasSpringDataJpa;

import com.example.AppVendasSpringDataJpa.modelos.Cliente;
import com.example.AppVendasSpringDataJpa.modelos.Pedido;
import com.example.AppVendasSpringDataJpa.repositorios.RepositorioClientesOLD;
import com.example.AppVendasSpringDataJpa.repositorios.RepositorioPedidosOLD;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class ControladorPedidoOLD {
    @Autowired
    RepositorioPedidosOLD repositorioPedidosOLD;

    @Autowired
    RepositorioClientesOLD repositorioClientesOLD;

    @GetMapping("/clientes")
    public List<Cliente> findAll(){
        return repositorioClientesOLD.findAll();
    }

    @GetMapping("/pedidos")
    public List<Pedido> findAllP(){
        return repositorioPedidosOLD.findAll();
    }

    @PostMapping("/pedidos")
    public Pedido criaPedido (@RequestBody Pedido pedido){
        return repositorioPedidosOLD.save(pedido);
    }
}
