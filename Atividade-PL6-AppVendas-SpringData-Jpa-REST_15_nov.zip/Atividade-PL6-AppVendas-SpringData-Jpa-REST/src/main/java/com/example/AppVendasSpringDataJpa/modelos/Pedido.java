package com.example.AppVendasSpringDataJpa.modelos;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Data
@NoArgsConstructor
@Table(name="PEDIDO")
public class Pedido {
    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private Integer id;
    private Timestamp data_pedido;
    private Double total;
    @ManyToOne(fetch=FetchType.EAGER, optional = false)
    @JoinColumn(name="CLIENTE_ID",referencedColumnName="ID")
    private Cliente cliente;

    public Pedido(Timestamp data_pedido, Double total, Cliente cliente) {
        this.data_pedido = data_pedido;
        this.total = total;
        this.cliente = cliente;
    }
}
