package com.example.PrimeiraAppSpringBoot;

import org.springframework.stereotype.Service;

@Service
public class Fibo {
    int fib(int n)
    {
        // Base Case
        if (n <= 1)
            return n;

        // Recursive call
        return fib(n - 1)
                + fib(n - 2);
    }
}
