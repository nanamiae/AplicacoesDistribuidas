package com.example.PrimeiraAppSpringBoot;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class MinhaConfiguracao {
    @Bean(name = "nome.app")
    public String getNomeAplicacao(){
        return "App Spring Boot Ola Mundo!";
    }

    @Bean(name = "nome.autor")
    public String getNomeAutor(){
        return "Alexandre Fonte";
    }
}
