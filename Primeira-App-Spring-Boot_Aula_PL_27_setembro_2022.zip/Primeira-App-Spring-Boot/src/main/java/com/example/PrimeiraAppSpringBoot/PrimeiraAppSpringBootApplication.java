package com.example.PrimeiraAppSpringBoot;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;

@SpringBootApplication
@RestController
public class PrimeiraAppSpringBootApplication implements ApplicationRunner {

	public static void main(String[] args) {
		SpringApplication.run(PrimeiraAppSpringBootApplication.class, args);
	}

	@GetMapping(value = "/getconta",produces = "Application/json")
	public Conta getContabyId(@RequestParam("id") long id) {
		return new Conta(id,"Alexandre","Castelo Branco",
				123456789,1234,1000.0, LocalDateTime.now());
	}

	@Autowired
	@Qualifier("nome.app")
	private String nomeapplicacao_bean_config;
	@Autowired
	@Qualifier("nome.autor")
	private String nomeautor_bean_config;
	@Value("${server.port}")
	Integer porta;
	@Value("${nome.autor}")
	String nomeautor;
	@Value("${url.app}")
	private String urlbase;
	@Autowired
	private Fibo fibonacciservice; //= new Fibo();

	//URI: localhost:8080/fibo?n=10
	@GetMapping(value = "fibo")
	public int getNumeroFibonacci(@RequestParam("n") int n) {
		return fibonacciservice.fib(n);
	}

	@Override
	public void run(ApplicationArguments args) throws Exception {
		System.out.println("###### Ola Mundo desde o Application Runner! #####");
		System.out.println("Nome da app (Config lida do Bean): "+this.nomeapplicacao_bean_config);
		System.out.println("Nome do Autor (Config lida do Bean): "+this.nomeautor_bean_config);
		System.out.println("A minha app está à escuta na porta (Config lida do application.properties): "+this.porta);
		System.out.println("O autor é (Config lida do application.properties): "+this.nomeautor);
		System.out.println("O urlbase da app (Config lida do application.properties): "+this.urlbase);

		for(int i=0; i<100; i++) {
			System.out.println(fibonacciservice.fib(i));
		}
	}
}
