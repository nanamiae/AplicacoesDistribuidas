package com.example.PrimeiraAppSpringBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrimeiraAppSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
