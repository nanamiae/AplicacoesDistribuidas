package com.example.APL7_Projecto_Base.seguranca;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

@EnableWebSecurity
@Configuration
public class ConfiguracoesSeguranca extends WebSecurityConfigurerAdapter {
    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.authorizeRequests()
                .antMatchers("/","/login").permitAll()
                .antMatchers("/formregistar","/remover/**").hasRole("ADMIN")
                .antMatchers("/listar","/editar/**").hasAnyRole("ADMIN","USER")
                .anyRequest().authenticated()
                .and()
                .formLogin().loginPage("/login").permitAll()
                .defaultSuccessUrl("/listar")
                .and()
                .logout().logoutUrl("/logout").permitAll().logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
               // .invalidateHttpSession(true)
                .and()
                .exceptionHandling().accessDeniedPage("/acesso-negado")
                .and()
                .httpBasic();
    }

    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth.inMemoryAuthentication()
                .withUser("admin").password(
                        getcodificadorPasswords().encode("admin")).roles("ADMIN")
                .and()
                .withUser("utilizador").password(
                        getcodificadorPasswords().encode("123456")).roles("USER");
    }

    @Bean("codificador.bcrypt")
    public BCryptPasswordEncoder getcodificadorPasswords() {
        return new BCryptPasswordEncoder();
    }
}
