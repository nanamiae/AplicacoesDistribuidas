package com.example.AppVendasSpringDataJpa.modelos;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name="CLIENTE")
@Data
public class Cliente {
    @Id
    @Column(name="ID")
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private Integer id;
    @Column(name="NOME",length=100)
    private String nome;

    @JsonIgnore
    @OneToMany(mappedBy = "cliente",fetch = FetchType.LAZY,
            cascade= CascadeType.ALL)
    private List<Pedido> pedidos;

    public Cliente(String nome) {
        this.nome = nome;
    }

    public Cliente() {
    }
}
