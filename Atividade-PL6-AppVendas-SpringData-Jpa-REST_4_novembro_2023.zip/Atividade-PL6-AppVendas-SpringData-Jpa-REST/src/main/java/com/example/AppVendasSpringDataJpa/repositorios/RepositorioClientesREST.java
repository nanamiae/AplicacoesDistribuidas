package com.example.AppVendasSpringDataJpa.repositorios;

import com.example.AppVendasSpringDataJpa.modelos.Cliente;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Repository
public interface RepositorioClientesREST extends JpaRepository<Cliente,Integer> {
    /* Crie um método que cria um Cliente. AJPQL não suporta inserts.
     */
    // (1)+(4) - criar ou atualizar um cliente
    public Cliente save(Cliente cliente);

    /* Usando uma query JPQL consulte todos os clientes e ordene a consulta
pelo Id.*/
//(2)
    @Query(value = "select * from CLIENTE c where c.ID =?1",nativeQuery = true)
    public Optional<Cliente> getClienteById(Integer id);

   //(3) - consultar todos os clientes
    public List<Cliente> findAll();
    //(5)


}
