package com.example.AppVendasSpringDataJpa.repositorios;

import com.example.AppVendasSpringDataJpa.modelos.Pedido;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface RepositorioPedidosREST extends JpaRepository<Pedido,Integer> {
//(5)
public Pedido save(Pedido pedido);

//(6)
    @Query(value = "select * from PEDIDO p where p.CLIENTE_ID=?1",nativeQuery = true)
    public List<Pedido> getPedidosClienteByID(Integer id);
}
