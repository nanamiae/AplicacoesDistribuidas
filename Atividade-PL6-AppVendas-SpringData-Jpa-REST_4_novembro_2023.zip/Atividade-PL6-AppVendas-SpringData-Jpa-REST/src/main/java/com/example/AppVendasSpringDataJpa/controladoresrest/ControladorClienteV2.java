package com.example.AppVendasSpringDataJpa.controladoresrest;

import com.example.AppVendasSpringDataJpa.modelos.Pedido;
import com.example.AppVendasSpringDataJpa.repositorios.RepositorioClientesREST;
import com.example.AppVendasSpringDataJpa.repositorios.RepositorioPedidosREST;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

@RestController
@RequestMapping("/v2")
public class ControladorClienteV2 {
    @Autowired
    RepositorioPedidosREST repositorioPedidos;
    @Autowired
    RepositorioClientesREST repositorioClientes;

    @ResponseStatus(HttpStatus.CREATED)
    @PostMapping("/clientes/{idcliente}/pedidos")
    public Pedido criaNomePedidoParaClienteByID(@PathVariable("idcliente")
                                                Integer idcliente,
                                                @RequestBody Pedido pedido) {

        try {
            if (repositorioClientes.existsById(idcliente)) {
                return repositorioPedidos.save(pedido);
            } else {
                throw new ResponseStatusException(HttpStatus.NOT_FOUND, "O cliente não existe");
            }
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Pedido Invalido");
        }
    }
}
