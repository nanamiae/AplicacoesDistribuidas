package com.example.AppVendasSpringDataJpa;

import com.example.AppVendasSpringDataJpa.modelos.Cliente;
import com.example.AppVendasSpringDataJpa.modelos.Pedido;
import com.example.AppVendasSpringDataJpa.repositorios.RepositorioClientes;
import com.example.AppVendasSpringDataJpa.repositorios.RepositorioClientesREST;
import com.example.AppVendasSpringDataJpa.repositorios.RepositorioPedidos;
import com.example.AppVendasSpringDataJpa.repositorios.RepositorioPedidosREST;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.domain.Sort;

import java.sql.Timestamp;
import java.util.List;

@SpringBootApplication
public class AppVendasSpringDataJpaApplication implements ApplicationRunner {

	public static void main(String[] args) {
		SpringApplication.run(AppVendasSpringDataJpaApplication.class, args);
	}

	@Autowired
	RepositorioClientesREST repositorioClientes;

	@Autowired
	RepositorioPedidosREST repositorioPedidos;

	@Override
	public void run(ApplicationArguments args) throws Exception {
		Cliente cliente1= repositorioClientes.save(new Cliente("Alexandre Fonte"));
		repositorioClientes.save(new Cliente("Vasco"));

		repositorioPedidos.save(new Pedido(Timestamp.valueOf("2022-10-28 10:37:27"),
				1000.0,cliente1));
		repositorioPedidos.save(new Pedido(Timestamp.valueOf("2022-10-28 11:00:00"),
				1000.0,repositorioClientes.findById(1).get()));
		repositorioPedidos.save(new Pedido(Timestamp.valueOf("2022-10-28 10:37:27"),
				1000.0,repositorioClientes.findById(2).get()));


	}
}
