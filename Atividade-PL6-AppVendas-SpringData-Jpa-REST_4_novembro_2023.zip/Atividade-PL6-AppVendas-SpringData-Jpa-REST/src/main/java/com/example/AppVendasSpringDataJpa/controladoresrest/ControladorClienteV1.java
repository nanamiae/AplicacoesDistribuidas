package com.example.AppVendasSpringDataJpa.controladoresrest;

import com.example.AppVendasSpringDataJpa.modelos.Cliente;
import com.example.AppVendasSpringDataJpa.repositorios.RepositorioClientes;
import com.example.AppVendasSpringDataJpa.repositorios.RepositorioClientesREST;
import com.example.AppVendasSpringDataJpa.repositorios.RepositorioPedidos;
import com.example.AppVendasSpringDataJpa.repositorios.RepositorioPedidosREST;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;

@Controller
@ResponseBody
@RequestMapping("/v1")
public class ControladorClienteV1 {
    @Autowired
    RepositorioPedidosREST repositorioPedidos;
    @Autowired
    RepositorioClientesREST repositorioClientes;

    //(1) cria cliente
    // POST /clientes
    @RequestMapping(value = "/clientes", method = RequestMethod.POST)
    public ResponseEntity<Cliente> criaCliente(@RequestBody Cliente cliente) {
        try {
            return ResponseEntity.status(HttpStatus.CREATED).body(repositorioClientes.save(cliente));
        } catch (Exception e) {
            System.out.println(e.getLocalizedMessage());
            return ResponseEntity.badRequest().build();
        }

    }

    //(2) consultar cliente pelo ID
    // GET /clientes/{id}
    @RequestMapping(value = "/clientes/{id}", method = RequestMethod.GET)
    public ResponseEntity<Cliente> getClienteByID(@PathVariable("id") Integer id)
        {
            if (repositorioClientes.getClienteById(id).isPresent()) {
                return ResponseEntity.ok().body(repositorioClientes
                        .getClienteById(id).get());
            } else {
                return ResponseEntity.notFound().build();
            }


        }

        //(4) atualizar cliente
    @RequestMapping(value = "/clientes/{id}", method = RequestMethod.PUT)
    public ResponseEntity<Cliente> getClienteByID(@RequestBody Cliente cliente,
                                                  @PathVariable("id") Integer id)
    {
        try {
       if (repositorioClientes.existsById(id)) {
           repositorioClientes.save(cliente);
           return ResponseEntity.noContent().build();
       }
       else {
               repositorioClientes.save(cliente);
               return ResponseEntity.status(HttpStatus.CREATED).body(cliente);

       }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.CONFLICT).build();
        }
    }
}

