package com.example.DemoMVCThymeleaf4Out;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoMvcThymeleaf4OutApplicationTests {

	@Test
	void contextLoads() {
	}

}
