package com.example.DemoMVCThymeleaf4Out.controladores;

import com.example.DemoMVCThymeleaf4Out.modelos.Utilizador;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class ControladorUtilizador {

    //URI: /
    //localhost
    @GetMapping("/")
    public String index() {
        return "index.html";
    }

    //URI: /regista
    @PostMapping("/regista")
    public ModelAndView registaUtilizador(@ModelAttribute Utilizador utilizador,
                                          ModelAndView modelAndView) {
        System.out.println(utilizador.toString());
        modelAndView.addObject("utilizador",utilizador);
        modelAndView.setViewName("dados-utilizador.html");
        return modelAndView;
    }
}
