package com.example.DemoMVCThymeleaf4Out;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoMvcThymeleaf4OutApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoMvcThymeleaf4OutApplication.class, args);
	}

}
