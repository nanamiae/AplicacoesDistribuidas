package com.example.APL7_Projecto_Base.seguranca;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

@EnableWebSecurity
@Configuration
public class ConfiguracoesSeguranca extends WebSecurityConfigurerAdapter {

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.
                authorizeRequests()
                .antMatchers("/","/home","/login").permitAll()
                .antMatchers("/listar","/editar/**","/registareditar").hasAnyRole("ADMIN","NORMAL")
                .antMatchers("/registar","/formregistar","/remover/**").hasRole("ADMIN")
                .anyRequest().authenticated()
                .and()
                .formLogin()
                .loginPage("/login")
                .defaultSuccessUrl("/listar")
                .permitAll()
                .and()
                .logout().invalidateHttpSession(true)
                /* Linha para enviar mensagem ao param.logout */
                .logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
                .and()
                .exceptionHandling().accessDeniedPage("/accesso-negado")
                 .and()
                .httpBasic();
    }

    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth.inMemoryAuthentication()
                .withUser("admin")
                .password(getCodificador().encode("admin"))
                .roles("ADMIN")
                .and()
                .withUser("utilizador")
                .password(getCodificador().encode("123456"))
                .roles("NORMAL");
    }

    @Bean("codificador.bcrypt")
    public BCryptPasswordEncoder getCodificador(){
        return new BCryptPasswordEncoder();

    }
}
