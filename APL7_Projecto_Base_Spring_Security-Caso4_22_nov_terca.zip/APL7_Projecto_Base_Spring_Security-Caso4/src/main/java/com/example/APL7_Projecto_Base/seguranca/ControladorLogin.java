package com.example.APL7_Projecto_Base.seguranca;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class ControladorLogin {

    @GetMapping(value={"/login","/","/home","/logout"})
    public ModelAndView login() {
        return new ModelAndView("login");
    }

    @GetMapping("/accesso-negado")
    public String getAcessoNegado(){
        return "acesso-negado";
    }
}
