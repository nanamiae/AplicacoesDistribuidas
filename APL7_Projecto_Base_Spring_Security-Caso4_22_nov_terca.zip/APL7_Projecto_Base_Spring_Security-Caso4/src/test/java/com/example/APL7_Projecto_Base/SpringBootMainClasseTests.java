package com.example.APL7_Projecto_Base;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootMainClasseTests {

	@Test
	void contextLoads() {
	}

}
