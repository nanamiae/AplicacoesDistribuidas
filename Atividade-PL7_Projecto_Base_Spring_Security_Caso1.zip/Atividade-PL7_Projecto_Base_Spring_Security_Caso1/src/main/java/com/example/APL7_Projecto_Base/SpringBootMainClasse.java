package com.example.APL7_Projecto_Base;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;

import java.util.ArrayList;
import java.util.List;

@SpringBootApplication
@EnableWebSecurity
public class SpringBootMainClasse {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootMainClasse.class, args);
	}

	@Bean(name="bdutilizadores")
	public List<Utilizador> getBdUtilizadores() {
		return new ArrayList<>();
	}
}
