package com.example.MinhaPrimeiraAppSpringBoot;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class MinhaConfiguracao {

    @Bean(name = "nome.app")
    public String getNomeAplicacao() {
        return "App Spring Boot Ola Mundo!";
    }

    @Bean(name = "nome.autor")
    public String getNomeAutor() {
        return "Alexandre Fonte";
    }

    @Bean(name = "porta")
    public int getPorta() {
        return 8080;
    }
}
