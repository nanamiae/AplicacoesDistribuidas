package com.example.MinhaPrimeiraAppSpringBoot;

import com.example.MinhaPrimeiraAppSpringBoot.modelos.Conta;
import com.example.MinhaPrimeiraAppSpringBoot.servicos.Fibo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;

@SpringBootApplication
@RestController
public class MinhaPrimeiraAppSpringBootApplication implements ApplicationRunner {

	public static void main(String[] args) {
		SpringApplication.run(MinhaPrimeiraAppSpringBootApplication.class, args);
	}


	@Autowired
	@Qualifier("nome.app")
	String nomeapplicacao;

	@Autowired
	@Qualifier("nome.autor")
	String nomeautor;

	@Autowired
	@Qualifier("porta")
	int porta;

	@Value("${server.port}")
	int portaservidor;

	@Value("${nome.aplicacao}")
	String nomeapplicacaoprop;

	@Autowired
	Fibo servicofibonnaci;

	@Override
	public void run(ApplicationArguments args) throws Exception {
		System.out.println("###### Ola Mundo desde o Application Runner! #####");
		System.out.println(
				new Conta(1,"Alexandre",
				"CB",123456789,1234,
				2000.0,LocalDateTime.now())
						.toString());
		System.out.println("###### Eu sou a App "+nomeapplicacao+" ###");
		System.out.println("###### O autor é: "+nomeautor+" ###");
		System.out.println("###### A porta do servidor é "+porta+" ###");

		System.out.println("###### A porta do servidor é (Application.Properties) " +
				""+portaservidor+" ###");
		System.out.println("###### Eu sou a App (Application.Properties)"+nomeapplicacaoprop+" ###");

		for(int i=0;i<50;i++){
			System.out.println(this.servicofibonnaci.fib(i));
		}
	}

	/*
	    private long id;
    private String titular;
    private String morada;
    private long nif;
    private long pin;
    private double saldo;
    private LocalDateTime data_atual;
	 */
	//URI localhost:8080/getconta?id=100
	@GetMapping("/getconta")
	public Conta getContaById(@RequestParam("id") int id) {
		return new Conta(1,"Alexandre",
				"CB",123456789,1234,
				2000.0,LocalDateTime.now());
	}

	//Http GET /ola?nome=Alexandre%20Fonte
	@GetMapping(value = "/ola")
	public String olamundo(@RequestParam(value =
			"nome",defaultValue = "Mundo!") String nome){
		return "Olá " + nome + " da app "+this.nomeapplicacao;
	}

}
