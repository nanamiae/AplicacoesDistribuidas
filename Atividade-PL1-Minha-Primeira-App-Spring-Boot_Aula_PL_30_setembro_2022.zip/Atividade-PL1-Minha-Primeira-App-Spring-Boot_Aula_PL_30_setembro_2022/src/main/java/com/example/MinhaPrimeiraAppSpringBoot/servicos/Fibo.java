package com.example.MinhaPrimeiraAppSpringBoot.servicos;

import org.springframework.stereotype.Service;

@Service
public class Fibo {
    public int fib(int n)
    {
        // Base Case
        if (n <= 1)
            return n;

        // Recursive call
        return fib(n - 1)
                + fib(n - 2);
    }
}
