package com.example.MinhaPrimeiraAppSpringBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MinhaPrimeiraAppSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
