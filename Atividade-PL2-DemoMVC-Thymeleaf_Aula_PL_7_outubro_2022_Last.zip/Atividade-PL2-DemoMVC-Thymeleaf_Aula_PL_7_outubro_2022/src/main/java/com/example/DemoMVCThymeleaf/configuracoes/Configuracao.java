package com.example.DemoMVCThymeleaf.configuracoes;

import com.example.DemoMVCThymeleaf.modelos.Utilizador;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.ArrayList;
import java.util.List;

@Configuration
public class Configuracao {
    @Bean("lista.utilizadores")
    public List<Utilizador> getListUtilizadores(){
        return new ArrayList<Utilizador>();
    }
}
