package com.example.DemoMVCThymeleaf.controladores;

import com.example.DemoMVCThymeleaf.modelos.Utilizador;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;
import java.util.Random;

@Controller
public class ControladorUtilizadores {

    @Autowired
    @Qualifier("lista.utilizadores")
    List<Utilizador> listaUtilizadores;

    @GetMapping("/")
    public String index() {
        return "index.html";
    }

    @PostMapping("/regista")
    public ModelAndView registaUtilizador(@ModelAttribute Utilizador utilizador,
                                          ModelAndView modelAndView) {
        utilizador.setId(new Random().nextInt(10000));
        this.listaUtilizadores.add(utilizador);
        modelAndView.setViewName("dados-utilizador.html");
        modelAndView.addObject("utilizador",utilizador);
        return modelAndView;
    }

    @GetMapping("/listar")
    public String listarUtilizadores(Model modelo) {
        modelo.addAttribute("lista",this.listaUtilizadores);
        return "lista-utilizadores.html";
    }
}
