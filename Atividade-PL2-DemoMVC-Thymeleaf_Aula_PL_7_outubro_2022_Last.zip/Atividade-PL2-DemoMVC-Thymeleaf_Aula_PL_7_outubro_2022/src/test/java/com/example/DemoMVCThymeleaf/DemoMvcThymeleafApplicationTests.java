package com.example.DemoMVCThymeleaf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoMvcThymeleafApplicationTests {

	@Test
	void contextLoads() {
	}

}
