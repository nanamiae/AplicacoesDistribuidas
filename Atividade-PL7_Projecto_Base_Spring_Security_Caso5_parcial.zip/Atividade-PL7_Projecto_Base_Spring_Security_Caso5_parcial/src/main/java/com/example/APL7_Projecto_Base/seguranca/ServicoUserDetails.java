package com.example.APL7_Projecto_Base.seguranca;

import com.example.APL7_Projecto_Base.RepositorioUtilizadores;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
public class ServicoUserDetails implements UserDetailsService {

    @Autowired
    RepositorioUtilizadores repositorioUtilizadores;
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        if (!repositorioUtilizadores.findByNome(username).isPresent())
            throw new UsernameNotFoundException("Utilizador inexistente");
        else {
            UserDetails user = repositorioUtilizadores.findByNome(username).get();
            System.out.println(user.toString());
            return  user;
        }
    }
}
