package com.example.APL7_Projecto_Base;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import java.util.ArrayList;
import java.util.List;

@SpringBootApplication
public class SpringBootMainClasse implements ApplicationRunner {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootMainClasse.class, args);
	}

	@Bean(name="bdutilizadores")
	public List<Utilizador> getBdUtilizadores() {
		return new ArrayList<>();
	}

	@Autowired
	RepositorioUtilizadores repositorioUtilizadores;

	@Qualifier("codificador.bcrypt")
	@Autowired
	BCryptPasswordEncoder codificador;

	@Override
	public void run(ApplicationArguments args) throws Exception {
		repositorioUtilizadores.save(new Utilizador("admin","adf@ipcb.pt",
				codificador.encode("admin")));

	}
}
