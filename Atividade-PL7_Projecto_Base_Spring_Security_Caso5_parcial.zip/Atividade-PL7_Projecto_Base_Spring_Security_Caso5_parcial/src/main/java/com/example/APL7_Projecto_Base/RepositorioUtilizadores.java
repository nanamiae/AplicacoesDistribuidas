package com.example.APL7_Projecto_Base;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface RepositorioUtilizadores extends JpaRepository<Utilizador,Integer> {

    public Optional<Utilizador> findByNome(String nome);
}
