package com.example.AppVendasSpringDataJpa.modelos;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Table(name="PEDIDO")
public class Pedido {
    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private Integer id;
    private Timestamp data_pedido;
    private Double total;
    @ManyToOne
    @JoinColumn(name="CLIENTE_ID",referencedColumnName="ID")
    private Cliente cliente;
    //Setters e Getters


    public Pedido() {
    }

    public Pedido(Timestamp data_pedido, Double total, Cliente cliente) {
        this.data_pedido = data_pedido;
        this.total = total;
        this.cliente = cliente;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Timestamp getData_pedido() {
        return data_pedido;
    }

    public void setData_pedido(Timestamp data_pedido) {
        this.data_pedido = data_pedido;
    }

    public Double getTotal() {
        return total;
    }

    public void setTotal(Double total) {
        this.total = total;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }
}
