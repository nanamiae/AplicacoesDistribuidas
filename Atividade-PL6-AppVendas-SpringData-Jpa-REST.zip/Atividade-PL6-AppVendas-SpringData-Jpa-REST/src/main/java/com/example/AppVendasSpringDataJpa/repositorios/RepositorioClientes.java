package com.example.AppVendasSpringDataJpa.repositorios;

import com.example.AppVendasSpringDataJpa.modelos.Cliente;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
public interface RepositorioClientes extends JpaRepository<Cliente,Integer> {
    /* Crie um método que cria um Cliente. AJPQL não suporta inserts.
     */
    public Cliente save(Cliente cliente);

    /* Usando uma query JPQL consulte todos os clientes e ordene a consulta
pelo Id.*/

    @Query("select c from Cliente c")
    public List<Cliente> getTodosClientesOrderBy(Sort sort);

    /* Usando uma query JPQL consulte os clientes pelo nome usando a
cláusula LIKE.*
     */
    @Query("select c from Cliente c where c.nome LIKE %?1%")
    public List<Cliente> getTodosClientesPeloNome(String nome);

    @Query("select c from Cliente c where c.nome LIKE %:nome%")
    public List<Cliente> getTodosClientesPeloNomeParamNamed(@Param("nome") String nome);

    @Modifying
    @Transactional
    @Query(value = "insert into CLIENTE (nome) values (:name)", nativeQuery = true)
    public void criaClienteUsandoQueryNativa(@Param("name") String nome);

    @Modifying(clearAutomatically = true)
    @Transactional
    @Query("update Cliente c set c.nome = ?1 where c.id = ?2")
    public void updateNomeClientePeloIDUsandoQueryJava(String nome, Integer id);



}
