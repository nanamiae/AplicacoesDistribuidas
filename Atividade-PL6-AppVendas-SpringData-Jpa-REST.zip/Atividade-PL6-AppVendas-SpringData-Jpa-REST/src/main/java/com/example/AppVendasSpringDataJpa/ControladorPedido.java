package com.example.AppVendasSpringDataJpa;

import com.example.AppVendasSpringDataJpa.modelos.Cliente;
import com.example.AppVendasSpringDataJpa.modelos.Pedido;
import com.example.AppVendasSpringDataJpa.repositorios.RepositorioClientes;
import com.example.AppVendasSpringDataJpa.repositorios.RepositorioPedidos;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class ControladorPedido {
    @Autowired
    RepositorioPedidos repositorioPedidos;

    @Autowired
    RepositorioClientes repositorioClientes;

    @GetMapping("/clientes")
    public List<Cliente> findAll(){
        return repositorioClientes.findAll();
    }

    @GetMapping("/pedidos")
    public List<Pedido> findAllP(){
        return repositorioPedidos.findAll();
    }

    @PostMapping("/pedidos")
    public Pedido criaPedido (@RequestBody Pedido pedido){
        return repositorioPedidos.save(pedido);
    }
}
