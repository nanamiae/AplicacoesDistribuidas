package com.example.DemoMVCThymeleaf.controladores;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ControladorUtilizador {
    /*
    //URI: /
String index();
Este método retorna a Vista index.html
que contém um formulário Web para introdução dos dados do utilizador a registar.
     */
    @GetMapping("/")
    public String index() {
        return "index.html";
    }
}
