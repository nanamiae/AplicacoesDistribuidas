package com.example.DemoMVC.Rest.repositorios;

import com.example.DemoMVC.Rest.modelos.Conta;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@Repository
public class RepositorioContas {

        private final Map<Long, Conta> bdcontas = new HashMap<Long, Conta>();
        public Conta criaConta(Conta conta) {
            bdcontas.put(conta.getId(), conta);
            return conta;
        }
        public Optional<Conta> getContaById(Long id) {
            return Optional.ofNullable(bdcontas.get(id));
        }

    public Conta getContaById_(Long id) {
        return bdcontas.get(id);
    }

    }
