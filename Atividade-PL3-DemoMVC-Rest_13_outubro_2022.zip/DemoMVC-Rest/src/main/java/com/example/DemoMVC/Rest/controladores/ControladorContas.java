package com.example.DemoMVC.Rest.controladores;

import com.example.DemoMVC.Rest.modelos.Conta;
import com.example.DemoMVC.Rest.servicos.ServicoContas;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
public class ControladorContas {
    @Autowired
    private ServicoContas servicoContas;

    //URI: POST /createconta
    @PostMapping
    public Conta criar(@RequestBody Conta conta) {
        return servicoContas.servicoCriaConta(conta);
    }

    //URI: GET /getconta/{id}
    @GetMapping("/getconta/{id}")
   public Optional<Conta> consultar(@PathVariable("id") long id) {
        return servicoContas.servicoGetContaBy(id);
    }

}
