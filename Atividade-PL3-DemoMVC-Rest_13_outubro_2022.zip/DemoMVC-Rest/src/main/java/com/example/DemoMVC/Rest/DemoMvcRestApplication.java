package com.example.DemoMVC.Rest;

import com.example.DemoMVC.Rest.modelos.Conta;
import com.example.DemoMVC.Rest.servicos.ServicoContas;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.Random;

@SpringBootApplication
public class DemoMvcRestApplication implements ApplicationRunner {

	public static void main(String[] args) {
		SpringApplication.run(DemoMvcRestApplication.class, args);
	}

	@Autowired
	private ServicoContas servicoContas;
	@Override
	public void run(ApplicationArguments args) throws Exception {
		/*private long id; //Gerado aleatoriamente pela aplicação.
		private String titular;
		private String morada;
		private long nif;
		private long pin;
		private double saldo;*/
		/* Inicializamos a "BD" com 5 registos*/
		servicoContas.servicoCriaConta(new Conta(1,
				"alexandre","cb",134,1234,1000.0));
		servicoContas.servicoCriaConta(new Conta(new Random().nextInt(),
				"alexandre","cb",134,1234,10000.0));
		servicoContas.servicoCriaConta(new Conta(new Random().nextInt(),
				"alexandre","cb",134,1234,100000.0));
		servicoContas.servicoCriaConta(new Conta(new Random().nextInt(),
				"alexandre","cb",134,1234,1000000.0));
		servicoContas.servicoCriaConta(new Conta(new Random().nextInt(),
				"alexandre","cb",134,1234,10000000.0));
	}
}
