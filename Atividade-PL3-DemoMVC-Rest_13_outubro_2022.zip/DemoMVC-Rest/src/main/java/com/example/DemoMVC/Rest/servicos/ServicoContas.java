package com.example.DemoMVC.Rest.servicos;

import com.example.DemoMVC.Rest.modelos.Conta;
import com.example.DemoMVC.Rest.repositorios.RepositorioContas;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class ServicoContas {
    @Autowired
    private RepositorioContas repositorioContas;

    public Conta servicoCriaConta(Conta conta) {
        repositorioContas.criaConta(conta);
        return conta;
    }

    public Optional<Conta> servicoGetContaBy(long id) {
            return repositorioContas
                    .getContaById(id);
    }
}
